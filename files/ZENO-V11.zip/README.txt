//===========[ READ THIS FILE ]===============//
/* 
 Script ini gratis di YT : DrayXD Official
 Developer : Dray

NOTE : 
- Dilarang keras memperjual-belikan sc ini
- Rename wajib kasih credits @dray
- Dilarang menyalah gunakan script
- Script ini auto follow saluran bang dray
- Script asli dari youtube bang dray tidak mengandung backdoor
- Berhati-hati menggunakan file script dari orang selain bang dray
- Resiko ditanggung sendiri
/*
===================================================>
// Baca tutor dibawah agar nomer kamu tidak mudah terblokir
/*
1. jangan menggunakan nomor yang baru verif whatsapp
2. Diamkan nomor sebelum digunakan untuk bot minimal 24 jam
3. Setelah pasang bot ke nomer jangan langsung dipakai (diamkan 3-6 jam agar aman)
4. Beri jeda bot minimal 5 Menit setelah digunakan untuk bug, agar tidak terdeteksi spam
5. Wajib subrek yt bang dray:v
/*

// @ DrayXD Official